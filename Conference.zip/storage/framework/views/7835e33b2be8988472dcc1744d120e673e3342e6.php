
<script src="<?php echo e(asset('vendor/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/scrollax.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/main.js')); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.js"></script>
<?php /**PATH D:\Projects\Conference\resources\views/includes/_javascript.blade.php ENDPATH**/ ?>