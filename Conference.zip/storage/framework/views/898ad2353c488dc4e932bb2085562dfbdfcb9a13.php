<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" style="width: 140px;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
            aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> <?php echo e(__('index.navbarMenu')); ?>

        </button>

        <div class="collapse navbar-collapse" id="ftco-nav"
        style="<?php echo e(App::islocale('ar')? "padding-right: 62%;":""); ?>">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item <?php echo e(Request::is('/')? "active":""); ?>"><a href="<?php echo e(route('home')); ?>" class="nav-link"><?php echo e(__('index.home')); ?></a></li>
                
                
                
                
                <li class="nav-item <?php echo e(Request::is('contact')? "active":""); ?>"><a href="<?php echo e(route('contact')); ?>" class="nav-link"><?php echo e(__('index.contact')); ?></a></li>
                <?php if(App::islocale('en')): ?>
                <li class="nav-item cta mr-md-2"><a href="/language/ar" class="nav-link">Arabic</a></li>
                <?php else: ?>
                <li class="nav-item cta mr-md-2"><a href="/language/en" class="nav-link">English</a></li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Projects\Conference\resources\views/includes/_navbar.blade.php ENDPATH**/ ?>