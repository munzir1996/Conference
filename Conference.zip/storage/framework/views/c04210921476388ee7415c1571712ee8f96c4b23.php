<link href="<?php echo e(asset('vendor/css/open-iconic-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php if(App::islocale('ar')): ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.css">
<?php endif; ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/aos.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/bootstrap-datepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/jquery.timepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/icomoon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/style.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">


<?php /**PATH D:\Projects\Conference\resources\views/includes/_head.blade.php ENDPATH**/ ?>