<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="rtl">

<head>
    <title>لوحة التحكم | <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <?php echo $__env->make('admin.includes._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('stylesheets'); ?>
</head>

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

    <?php echo $__env->make('admin.includes._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BEGIN HEADER & CONTENT DIVIDER -->
    <div class="clearfix"></div>
    <!-- END HEADER & CONTENT DIVIDER -->

    <!-- BEGIN CONTAINER -->
    <div class="page-container">

        <?php echo $__env->make('admin.includes._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY-->
            <div class="page-content" style="min-height:1015px">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- END CONTENT BODY-->
        </div>
        <!-- END CONTENT -->

        <!-- BEGIN QUICK SIDEBAR -->
        <a href="#" class="page-quick-sidebar-toggler">
            <i class="icon-login"></i>
        </a>
        <div class="page-quick-sidebar-wrapper" data-close-on-body-click="false">
            <div class="page-quick-sidebar">

            </div>
        </div>
        <!-- END QUICK SIDEBAR -->

    </div>
    <!-- END CONTAINER -->

    <?php echo $__env->make('admin.includes._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.includes._javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/adapters/jquery.js')); ?>"></script>
    <script>
        $('.ck_editor').ckeditor();

        CKEDITOR.config.extraPlugins = 'justify';
        CKEDITOR.config.extraPlugins = 'bidi';

    </script>
    <?php echo $__env->yieldContent('scripts'); ?>


</body>

</html>
<?php /**PATH D:\Projects\Conference\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>