<!-- BEGIN CORE PLUGINS -->
<script src="<?php echo e(asset('vendor/adminjs/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/js.cookie.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/bootstrap-hover-dropdown.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/bootstrap-switch.min.js')); ?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->

<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?php echo e(asset('vendor/adminjs/app.min.js')); ?>" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo e(asset('vendor/adminjs/layout.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/demo.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/quick-sidebar.min.js')); ?>" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo e(asset('vendor/adminjs/toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/jquery.validate.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/additional-methods.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/select2.full.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/filterDropDown.min.js')); ?>" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS  -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo e(asset('vendor/adminjs/ui-toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendor/adminjs/login.min.js')); ?>" type="text/javascript"></script>
<!-- END PAGE LEVEL SCRIPTS -->


<?php /**PATH D:\Projects\Conference\resources\views/admin/includes/_javascript.blade.php ENDPATH**/ ?>