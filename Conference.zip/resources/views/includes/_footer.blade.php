<footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">

        <div class="row">
            <div class="col-md-12 text-center">

                <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright ©<script>
                        document.write(new Date().getFullYear());

                    </script> All rights reserved | This Website is made with <i class="icon-heart color-danger"
                        aria-hidden="true"></i> by <a href="#" target="_blank">Omega Team</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                </p>
            </div>
        </div>
    </div>
</footer>
