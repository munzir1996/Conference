<link href="{{asset('vendor/css/open-iconic-bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
@if (App::islocale('ar'))
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.css">
@endif
<link rel="stylesheet" href="{{asset('vendor/css/animate.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/owl.theme.default.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/magnific-popup.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/aos.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/ionicons.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/bootstrap-datepicker.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/jquery.timepicker.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/flaticon.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/icomoon.css')}}">
<link rel="stylesheet" href="{{asset('vendor/css/style.css')}}">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">


