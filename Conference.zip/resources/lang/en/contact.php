<?php



return [


'contactInfo'=>'Contact Information',
'contact'=>'Contact',

'address'=>'Address',
'phone'=>'Phone',
'email'=>'Email',

'name'=>'Enter your Name',
'email'=>'Enter your Email',
'subject'=>'Subject',
'message'=>'Message',

'sendMessage'=>'Send Message',

'question'=>'Would you like to participate in the exhibition or a scientific paper?',
'yes'=>'Yes',
'no'=>'No',

]
?>
