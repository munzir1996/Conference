<?php



return [
'navbarMenu'=>"Menu",


'home'=>'Home',
'contact'=>'Contact',

'join'=>'Join Conference',

'subtitle'=>'Business Leaders',
'title'=>'Arab African Conference For Smart Education 2019',
'date'=>'20-23 November 2019 - Los Angeles CA',

'name'=>'Enter your Name',
'email'=>'Enter your Email',
'phone'=>'Enter your Phone',
'joinNow'=>'Join now',

'news'=>'Recent News',
'about'=>'What is all about?',

'sponsers'=>'Sponsers',
'country'=>'Country',
'sector'=>'Sector',

'public'=>'public',
'private'=>'private',

'school'=>'School',
'colleage'=>'Colleage',
'university'=>'University',

'ticket'=>'Conference Ticket Pricing',
'price'=>'Joining Price',
'features'=>'ENJOY ALL THE FEATURES',

'feature1'=>'Accommodation with two days 5 star hotel',
'feature2'=>'Comprehensive conference services.',

'terms'=>'I have read and accept the terms and conditions',
'termsConditions'=>'Terms and Conditions',
'termsDescription'=>'I acknowledge the participant below that I have read the terms and conditions of participation and that the acceptance of the subscription form is an agreement to attend and commit to pay the prescribed fees, knowing that the invitation to participate in the name of another person to attend and representation by the participant.',

]
?>
